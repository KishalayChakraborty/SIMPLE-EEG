ADI is currently in the process of transitioning our op amps from SPICE netlists to LTspice models.  Your design contains a mixture of parts, where some have text based netlists and some have LTspice files.  Because of this, the tool is not able to generate any SPICE output.  We apologize for the inconvenience and are working on getting this fixed.  If you would like ADI to prioritize LTspice model generation for a particular part, please let your sales representative know or send feedback through this tool.

SPICE simulation supported by parts in your design:

